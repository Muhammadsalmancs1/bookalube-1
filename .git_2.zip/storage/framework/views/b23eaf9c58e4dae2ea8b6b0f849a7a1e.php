<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="<?php echo e(url('/')); ?>" class="">

            <img src="<?php echo e(asset('theme/img/Asset 1.png')); ?>" alt="" class="">
        </a>
    </div>
    <div class="menu-inner-shadow"></div>
    <ul class="menu-inner py-1">
        <?php echo $__env->make('layouts.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </ul>
</aside>
<?php /**PATH /home1/dspbbkte/dev.bookalube-admin.com/resources/views/layouts/include/aside.blade.php ENDPATH**/ ?>