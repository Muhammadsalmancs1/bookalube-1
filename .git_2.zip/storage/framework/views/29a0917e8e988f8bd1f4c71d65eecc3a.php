<?php $__env->startSection('page_title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6 col-md-10 mx-auto">
            <div class="d-flex justify-content-center">
                <div class="logo-image">
                    <img src="<?php echo e(asset('auth/assets/images/Asset 1.png')); ?>" alt="" class="">
                </div>
            </div>
            <h1 class="main-heading text-center mt-4">
                Forget Password
            </h1>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-lg-5 col-md-9 mx-auto">
            <form action="#" >
                <div class="mb-3 lube-input">
                    <label for="exampleFormControlInput1" class="form-label">Title</label>
                    <p><?php echo e($title); ?></p>
                </div>
                <div class="mb-3 lube-input">
                    <label for="exampleFormControlInput1" class="form-label">Message</label>
                    <p><?php echo e($description); ?></p>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/dspbbkte/dev.bookalube-admin.com/resources/views/auth/booking.blade.php ENDPATH**/ ?>