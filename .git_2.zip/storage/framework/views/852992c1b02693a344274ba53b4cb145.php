<?php $__env->startSection('template_title'); ?>
    Incoming Service
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="pt-3 pb-2">Registration</h4>
        <!-- Striped Rows -->
        <div class="card px-4 pb-4 ">
            <div
                class="d-flex justify-content-between align-items-md-center align-items-start flex-md-row flex-column ">
                <h5 class="card-header px-0 pb-3">Incoming Service</h5>
                <div class="mt-1">
                    <a href="<?php echo e(route('catalog.incoming-services.create')); ?>"
                       class="btn btn-primary mb-md-0 mb-3 mt-lg-1">Add Incoming Service</a>
                </div>
            </div>
            <div class="datatable-responsive mt-3">
                <table id="example" class="display" style="width:100%">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Percentage</th>
                        <th>Total Cost</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $incomingServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $incomingService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$i); ?></td>

                            <td><?php echo e($incomingService->percentage); ?></td>
                            <td><?php echo e($incomingService->total_value); ?></td>

                            <td>
                                <form action="<?php echo e(route('catalog.incoming-services.destroy',$incomingService->id)); ?>"
                                      method="POST">




                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm"><i
                                            class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                                </form>
                            </td>
                        </tr>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!--/ Striped Rows -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/dspbbkte/dev.bookalube-admin.com/resources/views/content/incoming-services/index.blade.php ENDPATH**/ ?>