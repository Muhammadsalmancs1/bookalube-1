<!-- Modal -->
<div class="modal fade" id="staticBackdrop<?php echo e($engine_oil->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
     aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Edit Engine Oil </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('catalog.engine-oils.update',$engine_oil->id)); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label" for="basic-default-fullname">Name</label>
                        <input type="text" class="form-control" name="name" id="basic-default-fullname" placeholder="Edit  Name"
                               value="<?php echo e($engine_oil->name); ?>" />
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="basic-default-fullname">Price</label>
                        <input type="number" class="form-control" name="price" id="basic-default-fullname" placeholder="Edit Price"
                               value="<?php echo e($engine_oil->price); ?>" />
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /home1/dspbbkte/dev.bookalube-admin.com/resources/views/content/engine-oil/edit.blade.php ENDPATH**/ ?>