<?php $__env->startSection('template_title'); ?>
    <?php echo e(__('Create')); ?> Make Combination
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="content-wrapper">
                    <!-- Content -->

                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="pt-3 pb-2">Registration</h4>
                        <!-- Striped Rows -->
                        <div class="card">
                            <h5 class="card-header">Make Combination Form</h5>
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('catalog.make-combinations.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo $__env->make('content.make-combination.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </form>
                            </div>
                        </div>
                        <div class="content-backdrop fade"></div>
                    </div>
                    <!-- Content wrapper -->
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/dspbbkte/dev.bookalube-admin.com/resources/views/content/make-combination/create.blade.php ENDPATH**/ ?>