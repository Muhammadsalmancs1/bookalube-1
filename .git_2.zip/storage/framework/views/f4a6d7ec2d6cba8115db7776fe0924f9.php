<?php $__env->startSection('template_title'); ?>
    Bays
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-4">
            <h5 class="card-header">Bay Timeslot</h5>
        </div>
        <div class="card mb-4">
            <h5 class="card-header">Select Time</h5>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('management.bay-timeslots.store')); ?>" id="timeIntervalsForm">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3 make-div">
                        <select class="form-select form-select " name="bay_id" id="">
                            <option selected>Select Bay</option>
                            <?php $__currentLoopData = $bays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($bay); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="add-more-time-div mb-2" id="timeIntervalTemplate">
                        <div class="row  p-0">
                            <div class="mb-3 col-lg-6">
                                <label class="form-label" for="basic-default-fullname">Start Time </label>
                                <input type="time" name="start_time[]" class="form-control" placeholder="Enter Date">
                            </div>
                            <div class="mb-3 col-lg-6">
                                <label class="form-label" for="basic-default-fullname">End Time</label>
                                <input type="time" name="end_time[]" class="form-control" placeholder="Enter Date">
                            </div>
                        </div>
                    </div>
                    <div class="add-more-make">

                    </div>
                    <div class="col-lg-6 ms-auto ">
                        <div class="d-flex justify-content-end">
                            <button type="button" id="addMoreTimeInterval" class="btn btn-warning me-2 add-more-time">
                                Add More
                            </button>
                            <button type="submit" class="btn btn-primary ">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
    <script>
        $(document).ready(function () {
            $('#addMoreTimeInterval').on('click', function () {
                var templateClone = $('#timeIntervalTemplate').html();
                $('.add-more-make').append(templateClone);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/dspbbkte/dev.bookalube-admin.com/resources/views/content/bay-timeslot/create.blade.php ENDPATH**/ ?>