<div class="card">
    <h5 class="card-header">Oil Filter</h5>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('catalog.oil-filters.store')); ?>" role="form" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
            <div class="mb-3 col-lg-6">
                <!-- <label class="form-label" for="basic-default-fullname">Name</label> -->
                <input type="text" class="form-control" name="name" id="basic-default-fullname"
                       placeholder="Enter Name"/>
            </div>
            <div class="mb-3 col-lg-6">
                <!-- <label class="form-label" for="basic-default-fullname">Name</label> -->
                <input type="number" class="form-control" name="price" id="basic-default-fullname"
                       placeholder="Enter Price"/>
            </div>
            </div>
            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary">Add</button>
            </div>
        </form>
    </div>
</div>

<?php /**PATH /home1/dspbbkte/dev.bookalube-admin.com/resources/views/content/oil-filter/create.blade.php ENDPATH**/ ?>