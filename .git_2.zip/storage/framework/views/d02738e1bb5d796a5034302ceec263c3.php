<?php $__env->startSection('template_title'); ?>
    Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="pt-3 pb-2">Registration</h4>

    <!-- Striped Rows -->
        <div class="card px-4 pb-4 ">
            <h5 class="card-header px-0">User Listing</h5>
            <div class="datatable-responsive">
                <table class="table table-striped table-hover">
                    <thead class="thead">
                    <tr>
                        <th>No</th>


                        <th>Email</th>

                        <th>Referral</th>
                        <th>Employee Name</th>
                        <th>Employee Number</th>
                        <th>Service Counter</th>


                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$i); ?></td>


                            <td><?php echo e($user->email); ?></td>

                            <td><?php echo e($user->referral); ?></td>
                            <td><?php echo e($user->employee_name); ?></td>
                            <td><?php echo e($user->employee_number); ?></td>
                            <td><?php echo e($user->service_counter); ?></td>













                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!--/ Striped Rows -->
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/dspbbkte/dev.bookalube-admin.com/resources/views/content/user/index.blade.php ENDPATH**/ ?>