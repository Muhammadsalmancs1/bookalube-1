<div class="modal fade" id="staticBackdrop<?php echo e($literCombination->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
     tabindex="-1"
     aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Edit Combination </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('catalog.liter-combinations.update',$literCombination->id)); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <div id="formMain">
                <div class="modal-body form-div" id="formDiv">
                    <div class="mb-3">
                        <label for="" class="form-label">Year</label>
                        <select id="year-dropdown" name="car_year_id" class="form-select">
                            <option>Select Year</option>
                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($key == $literCombination->car_year_id ? 'selected' : ''); ?>>
                                    <?php echo e($year); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="" class="form-label">Brand</label>
                        <select id="brand-dropdown" name="car_brand_id" class="form-select">
                            <option>Select Brand</option>
                            <?php $__currentLoopData = $carBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($key); ?>" <?php echo e($key == $literCombination->car_brand_id ? 'selected' : ''); ?>>
                                    <?php echo e($brand); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label mb-0 text-end me-2">Model</label>
                        <select id="model-dropdown" name="car_model_id" class="form-select">
                            <option>Select Model</option>
                            <?php $__currentLoopData = $carModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($key); ?>" <?php echo e($key == $literCombination->car_model_id ? 'selected' : ''); ?>>
                                    <?php echo e($model); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label mb-0 text-end me-2">Engine</label>
                        <select name="engine_id" id="engine-dropdown" class="form-select">
                            <option>Select Engine</option>
                            <?php $__currentLoopData = $carEngines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$engine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($key == $literCombination->engine_id ? 'selected' : ''); ?>>
                                    <?php echo e($engine); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label mb-0 text-end me-2">Liter</label>
                        <input type="number" name="liter" class="form-control"
                               id="exampleFormControlInput1" value="<?php echo e($literCombination->liter); ?>"
                               placeholder="Enter No.of Liter">
                    </div>
                </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startSection('page-script'); ?>
    <script>

        document.getElementById('year-dropdown').addEventListener('change', function (e) {
            var yearId = e.target.value;
            // AJAX call to get brands based on selected year
            fetch(`/get-brands/${yearId}`)
                .then(response => response.json())
                .then(data => {
                    var brandDropdown = e.target.closest('.form-div').querySelector('#brand-dropdown');
                    brandDropdown.innerHTML = '<option selected>Select Brand</option>'; // Reset
                    data.forEach(function (brand) {
                        $('#brand-dropdown').append('<option value="' + brand.car_brand.id + '">' + brand.car_brand.name + '</option>');
                    });
                })
                .catch(error => console.error('Error:', error));
            // Similar blocks can be added for other dropdowns like brand-dropdown to fetch models, etc.
        });

        document.getElementById('brand-dropdown').addEventListener('change', function (e) {
            var brandID = e.target.value; // Get selected year ID
            fetch(`/get-models/${brandID}`)
                .then(response => response.json())
                .then(data => {

                    var modelDropdown = e.target.closest('.form-div').querySelector('#model-dropdown');
                    modelDropdown.innerHTML = '<option selected>Select Model</option>'; // Reset
                    data.forEach(model => {
                        $('#model-dropdown').append('<option value="' + model.car_model.id + '">' + model.car_model.name + '</option>');
                    });
                })
                .catch(error => console.error('Error:', error));
        });

        document.getElementById('model-dropdown').addEventListener('change', function (e) {
            var modelID = e.target.value; // Get selected year ID
            fetch(`/get-engines/${modelID}`)
                .then(response => response.json())
                .then(data => {

                    var engineDropdown = e.target.closest('.form-div').querySelector('#engine-dropdown');
                    engineDropdown.innerHTML = '<option selected>Select Engine</option>'; // Reset
                    data.forEach(engine => {
                        $('#engine-dropdown').append('<option value="' + engine?.engine?.id + '">' + engine.engine.name + '</option>');
                    });
                })
                .catch(error => console.error('Error:', error));
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home1/dspbbkte/dev.bookalube-admin.com/resources/views/content/liter-combination/edit.blade.php ENDPATH**/ ?>