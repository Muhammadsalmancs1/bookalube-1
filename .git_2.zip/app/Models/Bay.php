<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Bay
 *
 * @property $id
 * @property $name
 * @property $created_at
 * @property $updated_at
 *
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Bay extends Model
{

    static $rules = [
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['name'];



    /**
     * @return \Illuminate\Database\Eloquent\Relations\hasMany
     */
    public function bayTimeSlot()
    {
        return $this->hasMany('App\Models\BayTimeslot');
    }



}
