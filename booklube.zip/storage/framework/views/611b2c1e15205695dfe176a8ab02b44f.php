<?php $__env->startSection('template_title'); ?>
    Book a Lube
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mt-4">
            <div class="col-lg-10 col-md-10 mx-auto">
                <div class="accordian-head">
                    <div class="form-number">

                    </div>
                    <h2 class="main-heading text-white text-center mb-0 pb-0">Home</h2>
                    <a href="" class="text-decoration-none text-white">
                    </a>
                </div>
            </div>
            <div class="col-lg-8 col-md-10 mx-auto mt-3">
                <?php $__currentLoopData = $vechiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vechile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="information-row mb-3">
                    <p class=" mb-0 pb-0"><?php echo e($vechile->car_name); ?></p>
                    <div class="d-flex flex-md-row flex-column justify-content-end w-100">

                        <?php
                        $booking =\App\Models\Booking::with(['vechile','vechile.engine','vechile.carYear','vechile.carModel','vechile.carBrand','bay','bayTimeSlot'])
                        ->where('vechile_id',$vechile->id)->get();
                        ?>
                        <?php if(count($booking) > 0): ?>
                        <a href="<?php echo e(route('upcoming-service',$vechile->id)); ?>" class="main-btn-blank px-3" style="width: fit-content; ">Upcoming Service</a>
                        <?php endif; ?>
                        <?php if(count($booking) > 0): ?>
                        <a href="<?php echo e(route('service-history',$vechile->id)); ?>" class="main-btn-blank px-3 mx-md-3" style="width: fit-content; ">Service History</a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('booking',$vechile->id)); ?>" class="main-btn2 px-3" style="width: fit-content; ">BookaLube</a>
                        <a href="<?php echo e(route('booking.edit',$vechile->id)); ?>" class="px-1 mx-1 " style="width: fit-content; color: black "><i
                                class="fa fa-fw fa-edit"></i> </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex justify-content-center mt-5 mb-4">
                    <a href="<?php echo e(route('addvechiles')); ?>" class="main-btn2 px-3 mt-lg-5 ">+ Add Vehicle</a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookalube\resources\views/frontend/home.blade.php ENDPATH**/ ?>