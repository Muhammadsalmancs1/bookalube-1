<!DOCTYPE html>
<html
    lang            = "en"
    class           = "light-style layout-navbar-fixed layout-menu-fixed"
    dir             = "ltr"
    data-theme      = "theme-default"
    data-assets-path= "<?php echo e(asset('theme')); ?>/"
    data-template   = "vertical-menu-template">
<head>
    <?php echo $__env->make('layouts.frontend.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<?php echo $__env->make('layouts.frontend.include.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<!-- / Layout wrapper -->
<?php echo $__env->make('layouts.frontend.include.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\bookalube\resources\views/layouts/frontend/app.blade.php ENDPATH**/ ?>