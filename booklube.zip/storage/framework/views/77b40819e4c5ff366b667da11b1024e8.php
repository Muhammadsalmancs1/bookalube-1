<!-- Dashboards -->
<li class="menu-item ">
    <a href="#" class="menu-link ">
        <i class="menu-icon tf-icons bx bx-home-circle"></i>
        <div data-i18n="Dashboards">Dashboard</div>
    </a>

</li>

<!-- registration -->
<li class="menu-item <?php echo e(Route::is('catalog.*') ? 'open active' : ''); ?>">
    <a href="javascript:void(0)" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bx-copy"></i>
        <div data-i18n="Extended UI">Registration</div>
    </a>
    <ul class="menu-sub">
        <li class="menu-item <?php echo e(Route::is('catalog.engines.*') ? 'active' : ''); ?> ">
            <a href="<?php echo e(route('catalog.engines.index')); ?>" class="menu-link">
                <div data-i18n="Perfect Scrollbar">Engine</div>
            </a>
        </li>

        <li class="menu-item <?php echo e(Route::is('catalog.models.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('catalog.models.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Model</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Route::is('catalog.car-brands.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('catalog.car-brands.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider"> Make</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Route::is('catalog.car-years.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('catalog.car-years.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Year</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Route::is('catalog.services.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('catalog.services.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Services</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Route::is('catalog.engine-oils.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('catalog.engine-oils.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Engine oil</div>
            </a>
        </li>

        <li class="menu-item <?php echo e(Route::is('catalog.air-filters.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('catalog.air-filters.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Air filters</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Route::is('catalog.fuel-filters.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('catalog.fuel-filters.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Fuel filters</div>
            </a>
        </li>


        <li class="menu-item <?php echo e(Route::is('catalog.oil-filters.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('catalog.oil-filters.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Oil filters</div>
            </a>
        </li>

        <li class="menu-item <?php echo e(Route::is('catalog.tranmission_oil') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('catalog.tranmission_oil')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Tranmission Oil</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Route::is('catalog.differntialoil') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('catalog.differntialoil')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Differntial Oil</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Route::is('catalog.transmission-filters.*') ? 'active' : ''); ?> ">
            <a href="<?php echo e(route('catalog.transmission-filters.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Transmission filters</div>
            </a>
        </li>


        <li class="menu-item <?php echo e(Route::is('catalog.year-combinations.*') ? 'active' : ''); ?> ">
            <a href="<?php echo e(route('catalog.year-combinations.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Year Combination</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Route::is('catalog.make-combinations.*') ? 'active' : ''); ?> ">
            <a href="<?php echo e(route('catalog.make-combinations.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Make Combination</div>
            </a>
        </li>

        <li class="menu-item <?php echo e(Route::is('catalog.model-combinations.*') ? 'active' : ''); ?> ">
            <a href="<?php echo e(route('catalog.model-combinations.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Model Combination</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Route::is('catalog.liter-combinations.*') ? 'active' : ''); ?> ">
            <a href="<?php echo e(route('catalog.liter-combinations.index')); ?>" class="menu-link">
                <div data-i18n="Text Divider">Liter Combination</div>
            </a>
        </li>


    </ul>
</li>
<li class="menu-item <?php echo e(Route::is('management.*') ? 'open active' : ''); ?>">
    <a href="javascript:void(0)" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bx-copy"></i>
        <div data-i18n="Extended UI">Time Slot</div>
    </a>
    <ul class="menu-sub">
        <li class="menu-item <?php echo e(Route::is('management.bays.*') ? 'active' : ''); ?> ">
            <a href="<?php echo e(route('management.bays.index')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-file"></i>
                <div data-i18n="Text Divider">Bay</div>
            </a>
        </li>

        <li class="menu-item <?php echo e(Route::is('management.bay-timeslots.*') ? 'active' : ''); ?> ">
            <a href="<?php echo e(route('management.bay-timeslots.index')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-file"></i>
                <div data-i18n="Text Divider">Bay Time Slot</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(Route::is('management.leave-managements.*') ? 'active' : ''); ?> ">
            <a href="<?php echo e(route('management.leave-managements.index')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-file"></i>
                <div data-i18n="Text Divider">Leave Management</div>
            </a>
        </li>
    </ul>
</li>

<li class="menu-item <?php echo e(Route::is('users.*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('users.index')); ?>" class="menu-link">
        <i class="menu-icon tf-icons bx bx-file"></i>
        <div data-i18n="Text Divider">Register Customers</div>
    </a>
</li>


















<li class="menu-item <?php echo e(Route::is('catalog.booking.*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('catalog.booking')); ?>" class="menu-link">
        <i class="menu-icon tf-icons bx bx-file"></i>
        <div data-i18n="Text Divider">Incoming Booking</div>
    </a>
</li>

<li class="menu-item <?php echo e(Route::is('catalog.incoming-services.*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('catalog.incoming-services.index')); ?>" class="menu-link">
        <i class="menu-icon tf-icons bx bx-file"></i>
        <div data-i18n="Text Divider">Incoming Services</div>
    </a>
</li>
<?php /**PATH C:\xampp\htdocs\bookalube\resources\views/layouts/include/sidebar.blade.php ENDPATH**/ ?>