<?php $__env->startSection('template_title'); ?>
    <?php echo e(__('Create')); ?> Make Liter Combination
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="pt-3 pb-2">Liter Combination</h4>
                        <!-- Striped Rows -->
                        <div class="card">
                            <h5 class="card-header">Make Combination Form</h5>
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('catalog.liter-combinations.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo $__env->make('content.liter-combination.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </form>
                            </div>
                        </div>
                        <div class="content-backdrop fade"></div>
                    </div>
                    <!-- Content wrapper -->
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookalube\resources\views/content/liter-combination/create.blade.php ENDPATH**/ ?>